import json

def get_resource_status():

    with open("/var/www/html/status.json") as f:
        j = json.load(f)

    return {
        "cpu": {
            "temperature_c": j["cpu_temp_c"],
            "load": [
                float(j["load_1"]),
                float(j["load_5"]),
                float(j["load_15"]),
            ],
        },
        "memory": {
            "used": j["mem_used"],
            "available": j["mem_available"],
            "swap_used": j["swap_used"],
        },
        "storage": {
            "sd": {
                "used": j["sd_used"],
                "free": j["sd_free"],
                "percent": j["sd_pct"],
            },
            "ssd": {
                "used": j["ssd_used"],
                "free": j["ssd_free"],
                "percent": j["ssd_pct"],
            },
        },
    }
