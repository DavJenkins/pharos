import json

def get_system_status():

    with open("/var/www/html/status.json") as f:
        j = json.load(f)

    return {
        "hostname": j["hostname"],
        "platform": j["platform"],
        "uptime": j["uptime"],
    }
