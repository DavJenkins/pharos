import json
import subprocess

from app.services.network import get_network_status
from app.services.system import get_system_status
from app.services.resources import get_resource_status

def get_status():

    subprocess.run(
        ["/usr/local/bin/ark-status.sh"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )

    with open("/var/www/html/status.json") as f:
        legacy = json.load(f)

    network = get_network_status()
    system = get_system_status()
    resources = get_resource_status()

    status = {
        "state": legacy["system_state"],
        "sync": legacy["sync"],
        "debug": legacy["debug_mode"] == "ON",
        "updated": legacy["updated"],
    }

    return {
        #
        # New structured API
        #
        "network": network,
        "system": system,
        "resources": resources,
        "status": status,

        #
        # Legacy flat API (temporary)
        #
        **legacy,
    }
